import React from 'react'

function Test() {
  function taha(){
  var a=15;
  function taha1(){
    console.log(a);
  }
  return taha1;
  }
  taha();
  return (
    <div>
      



    </div>
  )
}

export default Test